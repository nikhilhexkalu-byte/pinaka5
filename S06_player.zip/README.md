# S06 — Setubandha: The Impossible Crossing

*The vanara engineers raise a causeway across the ocean to Lanka. No single hand records
whether a span is laid — five engineer-nodes keep a shared, replicated ledger of the work, and
a span counts as truly built only when the cluster has **agreed** on it beyond recall. When a
node falls behind, it rebuilds its picture of the bridge from a saved checkpoint plus whatever
log it can recover, and offers a **state proof** that its picture is sound. The host army will
only march across a causeway the ledger agrees is finished — a crossing the committed history
says is possible.*

## Target
A single **gateway** is exposed; it speaks JSON over HTTP. Behind it, five engineer-nodes
replicate a log of build commands under a consensus protocol with a notion of **finality**
(a committed command can never be taken back), alongside a **recovery** path that rebuilds a
node's state from a signed **snapshot** and a replayed **log suffix** and certifies it with a
**state proof**. Connection details for your instance are provided by the platform.

Explore the client API from the landing page and `/cluster/status`.

## Goal
Present the host with a **crossable causeway** — a state proof the recovery verifier accepts
as valid and complete — for a history the **finalized consensus** declares impossible. When
the gateway detects that your accepted state proof seals the bridge on a history the cluster
never actually committed, it reveals the crossing as an illusion and yields the sealed token
(the flag).

You hold no cluster secret and may forge nothing: you act only through the ordinary client API,
driving the cluster's own protocol. The flag is released by the gateway, server-side, only when
a genuinely accepted state proof is shown to contradict the finalized consensus history. There
is no flag in any file.
