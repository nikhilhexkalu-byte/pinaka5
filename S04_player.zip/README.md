# S04 — Vibhishana: The Oath of Refuge

*On the far shore at Setu Bandhan, where Rama's army gathers to bridge the ocean to Lanka, a
lone figure crosses the tide-line under a flag of surrender. It is **Vibhishana**, brother of
Ravana, who has forsaken Lanka and comes to beg **sharanagati** — the oath of refuge. The camp
is wary: a defector is a newcomer, provisional, trusted with nothing. Only those the Council has
vetted — allies like **Sugriva**, the vanara king — are raised to the inner camp. Yet the rite
that raises a sworn newcomer to trusted refuge binds the oath to the wrong thread. It fastens the
session, and forgets the soul.*

## Target

A single HTTP/JSON service — the **Sharanagati Gateway**. Connection details for your instance
are provided by the platform.

| Method / path | What it does |
|---|---|
| `GET /gateway/params` | Token format, the oath-of-refuge flow, and the binding rule. |
| `GET /gateway/roster` | The refuge-grants already on **public record**, and your target. |
| `POST /oath/swear` | Body `{"name": <str>, "sid": <str, optional>}` → a gateway-signed **provisional** session-ticket. |
| `POST /refuge/elevate` | Body `{"ticket": <token>, "grant": <token>}` → the provisional→trusted **token exchange**. |
| `POST /refuge/sanctum` | Body `{"ticket": <token>}` → releases the flag **only** to a valid **trusted** ticket. |

The public oath primitive (`pinaka_oath.py`) and the instance files (`params.json`,
`roster.json`) ship alongside this brief. Read them: the token format and the exact checks each
endpoint performs are documented there.

## The attestations

A **token** is `b64url(canonical_json(payload)) + "." + b64url(HMAC_SHA256(key, payload))`. The
payload is **authenticated, not secret** — anyone may decode and read it; nobody may alter it
without the signing key. Two server-side authorities sign:

- the **gateway** signs **session-tickets** `{typ:"session-ticket", sub, tier, sid, scope}`;
- the **Council** signs **refuge-grants** `{typ:"refuge-grant", sub, sid, aud, scope}`.

A provisional oath is open to any newcomer. Elevation to **trusted** refuge requires presenting
a valid Council **refuge-grant** — and only vetted allies hold one. You, Vibhishana, hold **no
grant of your own**.

## Goal

Make the gateway grant **you** trusted refuge: obtain a **valid trusted session-ticket** and
present it at `POST /refuge/sanctum`. You hold no signing key and must forge no signature — every
token you submit must be one the gateway or the Council genuinely signed. What you hold is only
what is public: the token format, the open oath endpoint, and the roll of grants already on
record.

Submit your trusted ticket to `POST /refuge/sanctum` as `{"ticket": "<token>"}`. The gateway
validates server-side and returns the sealed proclamation (the flag) only when a genuinely
valid **trusted** session-ticket is presented. There is no flag in any file.
