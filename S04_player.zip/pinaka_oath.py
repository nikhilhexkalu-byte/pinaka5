#!/usr/bin/env python3
r"""PINAKA S04 "Vibhishana — The Oath of Refuge" — PUBLIC oath primitive (no secrets).

This is the client-side token module the Sharanagati Gateway documents. It contains NO signing
keys: only the public token encoding (canonicalisation + base64url) and a decoder. You cannot
mint or alter a token with this module — the gateway and the Council hold the HMAC keys. You do
not need them.

TOKEN FORMAT  (authenticated, not secret)
-----------------------------------------
    token = b64url(canonical_json(payload)) + "." + b64url(HMAC_SHA256(key, b64url_payload))
    canonical_json(payload) = json.dumps(payload, sort_keys=True, separators=(",", ":"))

Two signing authorities, both server-side:
    gateway key  -> session-tickets  {typ:"session-ticket", sub, tier, sid, scope}
    council key  -> refuge-grants     {typ:"refuge-grant",   sub, sid, aud, scope}

THE OATH-OF-REFUGE FLOW (as published at GET /gateway/params)
-------------------------------------------------------------
    swear   : POST /oath/swear   {name, sid?} -> provisional ticket (tier="provisional").
              A newcomer MAY propose the session id `sid`. Trusted-ally names are refused.
    elevate : POST /refuge/elevate {ticket, grant} -> the provisional->trusted token exchange.
              Checks: ticket valid & tier="provisional"; grant valid & aud="refuge-elevation";
              ticket.sid == grant.sid. Re-issues a TRUSTED ticket for ticket.sub.
    sanctum : POST /refuge/sanctum {ticket} -> flag iff a valid TRUSTED ticket is presented.

The payload of any token can be read with `decode` below (it is signed, not encrypted). Study
the elevation step carefully: which of {identity, session, policy} does it actually re-bind
across the provisional->trusted transition, and which does it leave unbound?
"""
import json, os, base64


def _b64u(b):  return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
def _ub64u(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def canonical_json(payload):
    """The exact byte-canonicalisation the gateway hashes under its HMAC."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def decode(token):
    """Read a token's payload WITHOUT a key (it is authenticated, not secret). Returns a dict."""
    return json.loads(_ub64u(token.split(".")[0]))


def tag_of(token):
    """Return the token's base64url HMAC tag (opaque without the key)."""
    return token.split(".")[1]


def load_params(path=None):
    here = os.path.dirname(os.path.abspath(__file__))
    with open(path or os.path.join(here, "params.json")) as f:
        return json.load(f)


def load_roster(path=None):
    here = os.path.dirname(os.path.abspath(__file__))
    with open(path or os.path.join(here, "roster.json")) as f:
        return json.load(f)


if __name__ == "__main__":
    # self-check: decode the published refuge-grant and show its fields (no key needed).
    roster = load_roster()
    grant = roster["grants_on_record"][0]["grant"]
    print("published grant payload:", decode(grant))
    print("(its session id and holder are both readable — the tag is not forgeable, but you "
          "do not need to forge anything.)")
