# S05 — Nala's Blueprint: The Secret Geometry

*The armies have reached the southern shore, and the ocean will not part. Only Nala — son of
Vishwakarma, the one architect who can make stone float — knows the true geometry of the Setu,
the bridge to Lanka. He recorded it all: the height of every pier, the sweep of the arch, the
keystone that locks the span. But the archive that survived him is wounded. The parity ledger
of the stone-measurements is torn and mis-copied; the blueprint itself is sealed under Nala's
own cipher. Rebuild the geometry the archive still remembers, break the seal the way Nala's
scribes left it breakable, and read the keystone — or the bridge will never hold.*

## What you are given

Two binary artifacts from Nala's archive, plus the public description of their formats
(`blueprint_format.txt`). The formats are public; the measurement **data** and the blueprint
**content** are not.

| File | What it is |
|---|---|
| `parity.rsc`      | The stone-measurement parity record: a Reed-Solomon codeword over a finite field protecting the true pier measurements. Some symbols are **corrupted**, some are **erased**. |
| `archive.sealed`  | The encrypted blueprint archive: two authenticated-encryption records — a measurement **manifest** and the secret **blueprint** — each with its nonce, ciphertext and MAC tag. |
| `blueprint_format.txt` | The public container/plaintext formats for both files (field layouts, the AEAD construction, the manifest/blueprint plaintext schemas). |

Nothing here is random filler. The flag is **not** present in any file, and neither is the
AEAD key.

## The bridge geometry (the design law)

Nala's arch is a true parabola. Index the piers `i = 0, 1, …, k-1`; the true pier heights lie
exactly on one quadratic

```
h(i) = A·i² + B·i + C .
```

The **keystone** is the arch's vertex height, `apex = C − B²/(4A)` — an exact rational. This
over-determined constraint both **confirms** a correct measurement recovery (all piers must lie
on one parabola) and **supplies** the keystone apex, which the parity record never stores.

## Your goal (three threads, all required)

1. **Decode the parity record (ECC).** Reverse `parity.rsc`, drop the erasures, and run
   Reed-Solomon error-correction (e.g. Berlekamp–Welch) to recover the `k` true stone
   measurements — the pier heights — exactly. (`2e + f ≤ n − k`, so the decode is unique.)
2. **Fit the arch (geometry).** Verify the heights are co-parabolic and derive the exact
   rational **keystone apex**.
3. **Break the seal (cryptanalysis).** The archive's two records were sealed under the **same
   nonce** — a two-time pad. Rebuild the manifest plaintext from your recovered measurements
   and apex (the format is public), XOR it against the manifest ciphertext to recover the
   reused keystream, then XOR that keystream against the blueprint ciphertext to decrypt the
   secret **keystone seal**. No key, no brute force.

Present `measurements`, `keystone_apex` and `seal` to Nala's seal (the validator). It checks
all three against the archive's true geometry server-side and, only on an exact match, returns
the flag. There is exactly one consistent answer; guessing will not find it.

## Submission

`POST /setu/keystone` with a JSON body:

```json
{
  "measurements":  [h0, h1, ..., h_{k-1}],
  "keystone_apex": [numerator, denominator],
  "seal":          "<64 hex chars>"
}
```

- **measurements** — the ordered list of ECC-recovered pier heights (integers).
- **keystone_apex** — the arch vertex height, as an exact reduced fraction `[numerator, denominator]`.
- **seal** — the `keystone_seal` recovered from the decrypted blueprint (lowercase hex).

All three must be exactly right together. A measurement set that ignores the corruption, an
apex that skips the geometry, or a "seal" taken from the raw ciphertext will be refused.
