# S02 — Ashokavana: The Veiled Sanctuary

*The bridge to Lanka is built; Hanuman crosses ahead of the host to find where Sita is held.
She waits in an Ashoka grove — but Lanka's pleasure-gardens were laid out from one royal plan,
and from the air they are **identical**: the same ring of marker stones, the same bowers, the
same shade. Hanuman's reconnaissance can measure the grove he sees, yet it cannot tell that
grove apart from its twins scattered across the island. Only one other thread survives that
does not lie: the quartermaster's **provisions ledger** — the rations a porter company carried
to the true sanctuary, and how far those rations could have carried them. Fuse what the stones
show with what the rations prove, and the veil lifts over exactly one garden.*

## What you are given

| File | What it is |
|---|---|
| `recon.survey` | Hanuman's reconnaissance of the grove's marker stones — a **custom, undocumented binary**. Several overhead images, each a set of stone observations in image coordinates. The camera's **detector-calibration record is damaged (zeroed)**, and a few observation records are **torn** (their checksums no longer match). |
| `city_model.json` | The ancient map: six candidate gardens, each with its **published local marker-stone layout (template)** and the **road node** it sits on, plus the royal supply depot. Several gardens share one layout exactly; the rest differ in a single stone. |
| `supply_records.json` | The quartermaster's **provisions ledger** (rations dispatched, rations returned, rations consumed per league) and the **royal road network**. One road segment's length was **overwritten** with a sentinel value; the published total road length lets you restore it. |

Nothing in these files is random filler — the whole corpus is one internally consistent record.
The flag is **not** present in any file.

## Your goal

Name the **one authentic Ashoka grove** where Sita is held, and prove you earned it:

1. **Reverse `recon.survey`.** Recover the images and their marker-stone observations; skip the
   torn records. Note that the camera's detector calibration is missing — you must recover it.
2. **Photogrammetry.** The grove floor is flat, so each image is a weak-perspective (scaled,
   rotated, shifted) view of the stones, passed through one **global detector-defect matrix D**
   that is the same for every image. Using the metric **anchor image** (the one taken square-on,
   with unit scale and no rotation or shift), recover `D` for a candidate's published template,
   then check whether **every other image** is an exact view of that same template under that
   one `D`. Gardens that pass are the genuine look-alikes; the others are decoys. The genuine
   gardens share one layout, so **photogrammetry alone cannot choose between them.**
3. **Supply records.** Repair the overwritten road edge, find each garden's shortest road
   distance from the depot, and read the distance the ledger implies:
   `(rations_dispatched − rations_returned) / rations_per_league`.
4. **Fuse.** The true sanctuary is the one look-alike garden whose depot road distance equals
   the ledger distance. Exactly one garden satisfies both the stones and the rations.

Present your answer, with the facts you recovered along the way, to the sanctuary seal (the
validator) for your instance. The seal checks everything server-side and, only on an exact
match, returns the flag. Guessing the garden alone will not pass — the recovered camera
defect, the look-alike family and the supply facts are all checked.

## Submission

`POST /sanctuary/verify` with a JSON body:

```json
{
  "garden_id": <int 0..5>,
  "detector": { "d00": [n, d], "d01": [n, d], "d10": [n, d], "d11": [n, d] },
  "template_digest": "<sha256 hex>",
  "authentic_family": [<garden_id>, ...],
  "repaired_edge": [u, v, length],
  "ledger_distance": <int>,
  "garden_distance": <int>
}
```

- **garden_id** — the one authentic Ashoka grove.
- **detector** — the global camera detector-defect matrix `D` you recovered, each entry a
  reduced fraction `[numerator, denominator]`.
- **template_digest** — a fingerprint of the authentic marker-stone layout: for every stone,
  the string `stone_id:px_num/px_den,py_num/py_den` (each coordinate as its exact reduced
  fraction), sorted ascending by `stone_id`, joined with `;`, hashed with SHA-256 (hex).
- **authentic_family** — the sorted list of candidate garden ids that are genuine look-alikes
  (photogrammetrically consistent with the recon).
- **repaired_edge** — the overwritten road segment, restored, as `[u, v, length]`.
- **ledger_distance** — the road distance implied by the provisions ledger.
- **garden_distance** — the authentic garden's shortest road distance from the depot.

All fields must be exactly right together. A grove that looks right but whose rations do not
agree — or an answer that skipped the camera-defect correction or trusted a torn or
overwritten record — will be refused.
