#!/bin/sh
# per-connection handler: a one-line banner (identical to production), then the daemon.
printf '%s\n' 'Setu Bandhan. The sea waits. Lay the causeway, then call the fire.'
exec "${SETU_BIN:-./setu-bandhan}"
