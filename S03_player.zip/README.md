# S03 — Setu Bandhan: Trial by Agni

*The host has reached the southern shore, and the ocean will not part. So Nala, the vanara
architect — son of Vishwakarma — is set to build the impossible: a causeway of floating stones
across the sea to Lanka. The work-crews quarry the stones, inscribe each one, and ferry them
hand to hand down the growing span. When the last keystone is laid, Agni's fire is called to
test the bridge: only a causeway that truly holds will take the fire and let the army cross.*

*Nala's forge answers to no one but Nala. Yet the sea is patient, and stone that has been
carried back and forth too many times is no longer quite the stone the crew remembers.*

## Target

A single hardened daemon, `setu-bandhan`, speaking a **binary protocol over stdin/stdout**
(the deployed instance is wrapped on a TCP port; connection details for your instance are
provided by the platform). The binary is **stripped**. It is yours to study.

## The forge protocol (wire format)

All multi-byte integers are **little-endian**. Each request is a one-byte opcode followed by
its fields; each reply is as noted. Text replies are framed as `len:u16` then `len` bytes.

| Op | Name | Request | Reply |
|----|------|---------|-------|
| `0x01` | QUARRY | `type:u8` (0=mark, 1=anchor, 2=keystone) | `handle:u16` |
| `0x02` | INSCRIBE | `handle:u16, off:u16, len:u16, bytes` | `status:u8` |
| `0x03` | SURVEY | `handle:u16, off:u16, len:u16` | `len:u16, bytes` |
| `0x04` | RELEASE | `handle:u16` | `status:u8` |
| `0x05` | FERRY | `handle:u16, crew:u8` | `newhandle:u16` (hand a stone to another crew) |
| `0x06` | PLACE | `handle:u16` | `status:u8` (seat an anchor into the span) |
| `0x07` | CONSECRATE | `handle:u16` | the stone's rite fires |
| `0x10` | STATUS | — | `placed:u8, sealed:u8` |

A stone's **inscription/survey window** depends on the kind of stone it is. An anchor seats
into the span only if its inscribed index matches how far the causeway has come. When all the
anchors of the span are seated in order, the bridge **seals** — and only a sealed bridge may be
consecrated by fire.

## Goal

Call for **Agni's fire upon a sealed keystone** and make the forge release **Rama's seal**
(the flag). The forge issues it live, server-side, only to a genuinely completed and correctly
consecrated causeway — and it keeps a great many convincing forgeries on hand for anyone who
tries to hurry the sea. There is no flag in any file; guessing, and every shortcut Nala has
already foreseen, will only earn you the tide.

## Run it locally

```sh
# raw, no Docker: drive the daemon directly over a pipe
PINAKA_FLAG='PINAKA{local-practice}' ./setu-bandhan        # speaks the binary protocol on stdin/stdout

# or serve it on TCP 1337 exactly like the real target (needs socat)
PINAKA_FLAG='PINAKA{local-practice}' ./run.sh              # -> connect with: nc 127.0.0.1 1337
```
