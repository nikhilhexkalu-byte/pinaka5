#!/bin/sh
# Plain local runner (no Docker): serve the daemon on TCP 1337 with a practice flag.
export PINAKA_FLAG="${PINAKA_FLAG:-PINAKA{local_practice__now_build_it_for_the_real_target}}"
export SETU_BIN="./setu-bandhan"
exec socat -T120 TCP-LISTEN:1337,reuseaddr,fork EXEC:./serve.sh
