# S01 — Setu Bandhan: The Bridge of Beacons

*The ocean would not be crossed by force. To bind the setu — the great bridge to Lanka —
the vanara host raised a mesh of navigation beacons across the water, each one marking a
safe shoal, a depth, a bearing. Nala, the architect of the bridge, holds an ordinary
surveyor's hand on that mesh: he may read the public survey beacons, and nothing more.*

*But the bridge will not hold until its central anchor is raised, and the anchor answers
only to a seal kept deep inside the mesh — in the vault that no surveyor was ever meant to
reach.*

## Target
Only the **Setu gateway** is exposed; it speaks JSON over HTTP. Behind it, an internal
service mesh (a route-resolver, an identity-broker, a beacon-deputy, and the anchor-vault)
runs on the loopback and trusts only mesh-signed peers. Connection details for your
instance are provided by the platform.

You are **not** given credentials. An ordinary survey operator's hand is enough to begin —
and everything an ordinary client is served is fair game.

## Goal
Make the mesh **raise the Setu bridge-anchor** on your command, and obtain the sealed
proof that the bridge holds (the flag). The anchor is a **protected vault operation**: it
is reached only by getting the mesh to act, on your behalf, against a target it was built
to keep internal — the deputy will carry your request further than your own hand ever
could, if you can get it to.

The flag is released by the vault, server-side, only when the anchor is genuinely raised
with a seal drawn from the mesh's own interior. There is no flag in any file you are given.
